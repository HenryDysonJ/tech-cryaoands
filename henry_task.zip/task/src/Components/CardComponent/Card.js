import React, { useEffect, useState } from "react";
import "./Card.css";
import axios from "axios";
import { BiDotsVertical } from "react-icons/bi";
import { AiFillStar } from "react-icons/ai";
import Form from "../Form/Form";
import moment from "moment";

const Card = () => {
  const [todo, setTodo] = useState();
  
  const getList = () => {
    axios
      .get("https://63119bae19eb631f9d7566e8.mockapi.io/api/v1/todo")
      .then((res) => {
        console.log("res==>", res);
        setTodo(res.data);
      })
      .catch((error) => {
        console.log("=erroe==>", error);
      });
  };
  useEffect(() => {
    getList();
  }, []);

  return (
    <>
      <nav class="navbar navbar-light bg-primary p-4">
        <div className="container-fluid">
          <span className="title">Card</span>
          <div>
          <Form reload={getList} />

          </div>
        </div>
      </nav>
      <div className="m-2 add-btn" >
      </div>
    
      <div className="col-12 p-4 ">
        <div className="row">
          {todo &&
            todo.map((item) => {
              return (
                <div className="col-lg-3 col-md-4 col-sm-12">
                  <div className="card-root">
                    <div className="card-body">
                      <div className="d-flex">
                        <span className="date">
                          {moment(item.createdAt).format("MMM Do YYYY")}
                        </span>
                        <div className="over d-flex">
                          <div className="stadot">
                            <span className="star">
                              <AiFillStar fontSize={20} />
                            </span>
                            <span className="dot">
                              <BiDotsVertical fontSize={20} />
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="card-mid">{item.title}</div>
                      <div className=" button d-flex">
                        <button class="btn btn-outline-danger">
                          {item.estimation} Hours
                        </button>

                        <button type="button" className="btn btn-secondary">
                          {item.goal}
                        </button>
                      </div>
                     
                    </div>
                  </div>
                </div>
              );
            })}
        </div>
      </div>
    </>
  );
};

export default Card;
