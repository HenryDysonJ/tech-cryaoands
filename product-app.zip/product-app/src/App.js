import React from 'react'
import { BrowserRouter, Routes,Route } from 'react-router-dom';
import "./App.css";
import HomePage from './Components/HomePage/HomePage';
import LoginPage from './Components/LoginPage/LoginPage';
import Pixcel from "./Components/Pixcel5/Pixcel";
const App = () => {
  return (
    <div>
      <BrowserRouter>
      <Routes>
        <Route path='/home' element={<HomePage/>}/>
         <Route path='/phone' element={<Pixcel/>}/>
        <Route path='/' element={<LoginPage/>}/>
       </Routes>
      </BrowserRouter>
    </div>
  )
}

export default App