import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Modal } from "react-bootstrap";
import "./Pixcel.scss";
import { useLocation } from "react-router-dom";
import { AiOutlineCloseCircle } from "react-icons/ai";
import { IoMdStar } from "react-icons/io";
import { IoMdStarHalf } from "react-icons/io";

const Pixcel = () => {
  const [show, setShow] = useState(true);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(false);
  let location = useLocation();
  let pixcel = location.state.id;

  console.log("pixcel", pixcel);

  return (
    <>
      <Modal
        show={show}
        onHide={handleClose}
        onClick={handleShow}
        centered
        size="md"
        closeButton
      >
        {/* {
          pixcel && pixcel.map((item)=>{
            return(
              <>
              
              </>
            )
          })
        } */}
        <div className="row">
          <div className="head col-9">
            <span>Pixcel 5</span>
          </div>
          <div className="close col-2">
            <AiOutlineCloseCircle />
          </div>
        </div>
        <Modal.Body>
          <div className="img row">
            <div className="arrow col-sm"></div>
            <div className="arrow col-sm">
              <img src="" className="phone" alt="" />
            </div>
            <div className="arrow col"></div>
          </div>
          <div className="detail">
            <table>
              <thead></thead>
              <tbody>
                <tr>
                  <td className="key">Color</td>
                  <td className="value">Black</td>
                  <td className="value">Blue</td>
                  <td className="value">White</td>
                </tr>
                <tr>
                  <td className="key">Display</td>
                  <td className="value">...</td>
                </tr>
                <tr>
                  <td className="key">Dimention & weight</td>
                  <td className="value">...</td>
                </tr>
                <tr>
                  <td className="key">Batery & Charging</td>
                  <td className="value">...</td>
                </tr>
                <tr>
                  <td className="key">Memory</td>
                  <td className="value">...</td>
                </tr>
                <tr>
                  <td className="key">Storage</td>
                  <td className="value">...</td>
                </tr>
                <tr>
                  <td className="key">Processor</td>
                  <td className="value">...</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div className="row footer">
            <div className="col-sm-4">
              <div className="star col">
                <h6>$499</h6>
                <span className="start">
                  <IoMdStar />
                </span>
                <span className="start">
                  <IoMdStar />
                </span>
                <span className="start">
                  <IoMdStar />
                </span>
                <span className="start">
                  <IoMdStarHalf />
                </span>
                <span className="rate">(2.5k)</span>
              </div>
            </div>
            <div className="col-sm-4"></div>
            <div className="col-sm-4">
              <button className="btn btn-buynow" onClick={handleClose}>
                Buy Now
              </button>
            </div>
          </div>
        </Modal.Body>
      </Modal>
    </>
  );
};
export default Pixcel;
